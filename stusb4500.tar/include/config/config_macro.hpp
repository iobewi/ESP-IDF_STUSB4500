#pragma once
#include "config.hpp"

namespace stusb4500
{
    Config load_config_from_kconfig();

} // namespace stusb4500